﻿using uab.server.Data.Contracts;
using uab.server.Entities;

namespace uab.server.Data
{
    public class TodoAppDao: GenericDao<TodoApp>, ITodoAppDao
    {
    }
}
